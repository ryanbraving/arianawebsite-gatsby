const Messages = require("./components/bot.messages")
//**************Telegram Setup***********
const request = require("request-promise")
const TELE_TOKEN = process.env.Token_Inquiry
const URL = `https://api.telegram.org/bot${TELE_TOKEN}/`
const chat_id = process.env.Chat_id_Ryan


//**************Telegram Send Function***********
let telegram_promise = async(text, chat_id) => {
  if (typeof text == "object") text = JSON.stringify(text)
  const url = URL + `sendMessage?text=${text}&chat_id=${chat_id}`
  var result = await request.get(url)
  // console.log(result.body)
  return result
  // console.log("error:", error) // Print the error if one occurred
  // console.log("statusCode:", response && response.statusCode) // Print the response status code if a response was received
  // console.log("body:", body) // Print the HTML for the Google homepage.
}

exports.handler = async function(event, context, callback) {
  // TODO implement
  for (var i in event.Records) {
    var record = event.Records[i]
    // await telegram_promise(record, chat_id)
   
    if (record.eventName == "INSERT" ) {
      var text = "Nothing"
      const data = record.dynamodb.NewImage
        if (record.eventSourceARN.includes("PrivateCoaching-FR")){
          text = Messages.privateCoachingFR(data)
        }
      await telegram_promise(text, chat_id)
    } //if
    // else {
    //   text = `An Event happened in DynamoDB but is not an INSERT! Event is: ${record.eventName}.`
    //   await telegram_promise(text, chat_id)
    // } //else
  } //for
  const response = {
    statusCode: 200,
    body: JSON.stringify("Lambda function execution done"),
  }
  return response
}
